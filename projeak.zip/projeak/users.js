const users = [
  { id: "1",
    email: "gotk23.090@std.chiba-c.ed.jp",
    password: "Fyhhmmw5",
    name: "gotk23.090",
    access:"A",
  },
  { id: "2",
    email: "free@gmail.com",
    password: "free",
    name: "free",
    access:"B"
  },
  {
    id: "3",
    name: "Admin",
    email: "admin@gmail.com",
    password: "1234",
    access: "A"
  },
  {
    id: "4",
    name: "Vip",
    email: "vip@gmail.com",
    password: "1234",
    access: "B"
  },
  {
    id: "5",
    name: "User",
    email: "user@gmail.com",
    password: "1234",
    access: "NONE"
  }
]
